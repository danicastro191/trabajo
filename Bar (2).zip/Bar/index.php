<!DOCTYPE html>
<html>
<head>
	<title>Bar </title>
	<link rel="stylesheet" href="./style.css">


<h1 style="text-align:center;">Bar</h1>



	<a href="staff" >cajero  y mesero</a>
	<a href="admin">Administrador</a>


	
	<img src="https://attachment.outlook.live.net/owa/MSA%3Adanicastro1219%40hotmail.com/service.svc/s/GetAttachmentThumbnail?id=AQMkADAwATZiZmYAZC1mMDgxLTc5ZTAtMDACLTAwCgBGAAADXWim95yEN0aeH%2F7z0iHVPQcAZBKa2yhfiUiPAsesBQBLSQAAAgEMAAAAZBKa2yhfiUiPAsesBQBLSQAGYUfm9QAAAAESABAATrqWm3qXhEScVcGUSWXbmA%3D%3D&thumbnailType=2&isc=1&token=eyJhbGciOiJSUzI1NiIsImtpZCI6IjczRkI5QkJFRjYzNjc4RDRGN0U4NEI0NDBCQUJCMTJBMzM5RDlGOTgiLCJ0eXAiOiJKV1QiLCJ4NXQiOiJjX3VidnZZMmVOVDM2RXRFQzZ1eEtqT2RuNWcifQ.eyJvcmlnaW4iOiJodHRwczovL291dGxvb2subGl2ZS5jb20iLCJ1YyI6IjQ4NTg1YzgxMzA3YTQ0NTU5ZjQ3Mjg5MGQ3MmNhZWZmIiwidmVyIjoiRXhjaGFuZ2UuQ2FsbGJhY2suVjEiLCJhcHBjdHhzZW5kZXIiOiJPd2FEb3dubG9hZEA4NGRmOWU3Zi1lOWY2LTQwYWYtYjQzNS1hYWFhYWFhYWFhYWEiLCJpc3NyaW5nIjoiV1ciLCJhcHBjdHgiOiJ7XCJtc2V4Y2hwcm90XCI6XCJvd2FcIixcInB1aWRcIjpcIjE4OTk5NDcyNDI5MTIyMjRcIixcInNjb3BlXCI6XCJPd2FEb3dubG9hZFwiLFwib2lkXCI6XCIwMDA2YmZmZC1mMDgxLTc5ZTAtMDAwMC0wMDAwMDAwMDAwMDBcIixcInByaW1hcnlzaWRcIjpcIlMtMS0yODI3LTQ0MjM2NS00MDM1MDE3MTg0XCJ9IiwibmJmIjoxNjg0NDE4NzE0LCJleHAiOjE2ODQ0MTkzMTQsImlzcyI6IjAwMDAwMDAyLTAwMDAtMGZmMS1jZTAwLTAwMDAwMDAwMDAwMEA4NGRmOWU3Zi1lOWY2LTQwYWYtYjQzNS1hYWFhYWFhYWFhYWEiLCJhdWQiOiIwMDAwMDAwMi0wMDAwLTBmZjEtY2UwMC0wMDAwMDAwMDAwMDAvYXR0YWNobWVudC5vdXRsb29rLmxpdmUubmV0QDg0ZGY5ZTdmLWU5ZjYtNDBhZi1iNDM1LWFhYWFhYWFhYWFhYSIsImhhcHAiOiJvd2EifQ.fkpGJ7vtZtqrcq_0_ffpGuO4PTNCXl4hpY4zyFg6bkFoTKaS5SePXvzHayFIIngTJgPGgU2ZHwYUbGtCIWkT09wZR6-pCGFUEno9OQ9ZbHA1nsihfoQ_8ynwmD__tZh0z5BxeN7DC4CK0pYR24HtlyyvUce9n60mqlM11HX1YRn17BX0MvkcsozE8VgvVwZkCTjFec1HECLa5tEgSgWnetmSeTZrfF8giiHsX82yhxc9yqK_mGsTVDYoVkZ6GzGv0w-JYe1kOfZShZ4O6BbPurFfro8pBy92fKsLhTqg7IPtUqEy8ZsYCT3_UbMnWckHZhCFLsx1JVxAjc7jGGUlzA&X-OWA-CANARY=Dun0xCUizEuFjxk-ZFiuGZBeL-ioV9sYpkV_HKLuXrSjiU_EaIhhNkalo8j7t1iQId4iE07IhtI.&owa=outlook.live.com&scriptVer=20230428009.08&animation=true" width="250" height="250" />
	
</head>
<body>
</div>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>




	
</body>
</html>